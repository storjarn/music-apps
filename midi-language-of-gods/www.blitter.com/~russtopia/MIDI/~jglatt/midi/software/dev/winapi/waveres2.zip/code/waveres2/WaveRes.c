/* WaveRes2 -- A C example that plays a WAVE file embedded in this executable's resources
 * using PlaySound().
 */

/* Windows include files */
#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>

/* Here, I include #define's for my symbols used in my RESOURCE (.RC) and SOURCE (.C) files */
#include "resource.h"



/* ****************************** WinMain() ******************************** */
/* * Program Entry point */
/* ************************************************************************* */

int WINAPI WinMain(HINSTANCE hinstExe, HINSTANCE hinstPrev, LPSTR lpszCmdLine, int nCmdShow)
{
	/* Call PlaySound() to play the WAVE resource with an ID of 129 */
	if (!PlaySound("#129", 0, SND_RESOURCE))
	{
		MessageBox(0, "PlaySound() failed", "ERROR", MB_OK|MB_ICONEXCLAMATION);
		return(-1);
	}

	/* Exit */
	return(0);
}
