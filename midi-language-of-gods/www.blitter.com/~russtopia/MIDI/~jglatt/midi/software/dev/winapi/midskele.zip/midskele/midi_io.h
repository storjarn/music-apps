// Globals in midi_io.dll
__declspec(dllimport) HMIDIIN	MidiInHandle;
__declspec(dllimport) DWORD	MidiInID;
__declspec(dllimport) HMIDIOUT	MidiOutHandle;
__declspec(dllimport) DWORD	MidiOutID;

// Functions in midi_io.dll
DWORD WINAPI CloseMidiIn(HWND);
DWORD WINAPI OpenMidiIn(HWND, DWORD);
DWORD WINAPI CloseMidiOut(HWND);
DWORD WINAPI OpenMidiOut(HWND);
void WINAPI AllNotesOff(void);

// Functions in midi_io.c
void doMidiInDevDlg(void);
void doMidiOutDevDlg(void);
void CALLBACK midiInputEvt(HMIDIIN, UINT, DWORD, DWORD, DWORD);
