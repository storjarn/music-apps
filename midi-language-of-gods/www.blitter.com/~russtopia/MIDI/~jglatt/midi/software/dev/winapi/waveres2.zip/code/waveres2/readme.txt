This C example shows how to use a WAVE resource with PlaySound(). It is a
very trivial plain C example.

In Visual C++, I created a plain C "Application".

I added the WAVE file to my resource (in Microsoft Developer Studio) as so:

1). I flipped to the ResourceView.

2). I went up to the "Insert" menu and selected "Resource". The "Insert
Resource" dialog popped up.

3). In the "Insert Resource" dialog, I clicked on the "Import" button. A File
dialog popped up.

4). Under "Files of type:", I selected "Wave files (*.wav)". I now browsed
around and found the name of my desired WAVE file (which is a short "beep"
sound). I selected this filename to close the File Dialog.

5). Developer Studio now added this WAVE resource to my resource file, automatically
generating the symbol IDR_WAVE1 for it.

6). I saved this resource file to disk as "WaveRes2.rc" and then added this file to my
project. (In VC 4.0, that is under "Insert->Files". In VC 6.0, that is under
"Project->Add to Project->Files).

Now, I was ready to add my call to PlaySound(). I chose to make that call when
the program starts, in my WinMain() function. Here's what I did:

1). I needed to know the value for the IDR_WAVE1 symbol that Developer Studio
automatically generated. The value is needed for the call to PlaySound(). I went
up to the "View" menu and selected "Resource Symbols". This popped up the "Resource
Symbols" dialog.

2). In this dialog, I located the entry for IDR_WAVE1 and noted that it had a
value of 129. That means that the string I pass for the first arg to PlaySound()
must be "#129".

3). I went to my WinMain() functions and added the following line:

PlaySound("#129", 0, SND_RESOURCE | SND_NODEFAULT);

Note the SND_RESOURCE flag is specified.

4). I compiled the example. It worked. End of story.
