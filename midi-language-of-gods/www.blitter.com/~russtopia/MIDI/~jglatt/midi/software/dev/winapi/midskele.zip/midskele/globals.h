// ******************** functions
extern void				setMenuOptions(HWND hwnd);
extern void				loadSettings(void);
extern void				saveSettings(void);

// ******************** Global variables
extern HINSTANCE		MyInstance;
extern HWND				MainWindow;
extern HFONT			FontHandle;
extern HACCEL			MainAccelTable;
extern unsigned char	NoRelinquishFlag;