//==========================================================================
// mixabout.c
//
// This source file manages the "About" (IDD_ABOUTBOX) dialog. This dialog
// displays information about this app's version and copyright.
//
// The IDD_ABOUTBOX dialog is presented when the user selects the
// "Help -> About..." menu item in the main window.
//
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//
// Copyright (C) 1993 - 1997  Microsoft Corporation.  All Rights Reserved.
// Modified 2001 by Jeff Glatt
//==========================================================================

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <commdlg.h>
#include <commctrl.h>

#include "resource.h"
#include "mixapp.h"





// ************************* aboutDlgProc() **************************
// Dialog Procedure for the About (IDD_ABOUT) dialog.
//
// The IDD_ABOUTBOX dialog is presented when the user selects the
// "Help -> About..." menu item in the main window.
//
// ARGS:
//		Standard args for a dialog procedure.
//
// RETURNS:
//		Standard return for a dialog procedure.

BOOL APIENTRY aboutDlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_INITDIALOG:
		{
			return(TRUE);
		}

		case WM_COMMAND:
		{
			EndDialog(hwnd, 0);
		}
	}

	return(FALSE);
}
