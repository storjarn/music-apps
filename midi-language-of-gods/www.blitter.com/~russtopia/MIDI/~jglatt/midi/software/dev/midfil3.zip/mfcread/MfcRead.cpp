// MfcRead.cpp : Defines the class behaviors for the application.

#include "stdafx.h"
#include "MfcRead.h"
#include "MfcReadDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif





// App message map
BEGIN_MESSAGE_MAP(CMfcReadApp, CWinApp)
	//{{AFX_MSG_MAP(CMfcReadApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()





// The one and only CMfcReadApp object
CMfcReadApp theApp;





// **************************** CMfcReadApp() **************************
// App constructor

CMfcReadApp::CMfcReadApp()
{
}





// **************************** InitInstance() **************************
// App initialization

BOOL CMfcReadApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Create Main Dialog
	CMfcReadDlg dlg;

	// Save ptr to the main window
	m_pMainWnd = &dlg;

	// Do the dialog. When this returns, the dialog will have been closed by the user
	dlg.DoModal();

	// Return FALSE so that we exit the application, rather than start the app's message pump.
	return(FALSE);
}
