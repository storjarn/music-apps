// MfcWrite.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MfcWrite.h"
#include "MfcWriteDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif





// App message map
BEGIN_MESSAGE_MAP(CMfcWriteApp, CWinApp)
	//{{AFX_MSG_MAP(CMfcWriteApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()





// The one and only CMfcWriteApp object
CMfcWriteApp theApp;





// **************************** CMfcWritepp() **************************
// App constructor

CMfcWriteApp::CMfcWriteApp()
{
}





// **************************** InitInstance() **************************
// App initialization

BOOL CMfcWriteApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Create Main Dialog
	CMfcWriteDlg dlg;

	// Save ptr to the main window
	m_pMainWnd = &dlg;

	// Do the dialog. When this returns, the dialog will have been closed by the user
	int nResponse = dlg.DoModal();

	// Return FALSE so that we exit the application, rather than start the app's message pump.
	return FALSE;
}
