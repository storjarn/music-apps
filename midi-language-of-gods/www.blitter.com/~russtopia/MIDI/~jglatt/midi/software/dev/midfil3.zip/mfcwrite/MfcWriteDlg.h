// MfcWriteDlg.h : header file

/////////////////////////////////////////////////////////////////////////////
// CMfcWriteDlg dialog

class CMfcWriteDlg : public CDialog
{
// Construction
public:
	CMfcWriteDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMfcWriteDlg)
	enum { IDD = IDD_MFCWRITE_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfcWriteDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMfcWriteDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSaveMidi();
	afx_msg void OnFormat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
