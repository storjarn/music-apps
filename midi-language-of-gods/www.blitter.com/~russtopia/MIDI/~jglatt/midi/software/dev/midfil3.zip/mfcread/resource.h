//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MfcRead.rc
//
#define IDC_MIDI                        101
#define IDD_MFCREAD_DIALOG              102
#define IDC_LOAD                        102
#define IDR_MAINFRAME                   128

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
