//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Checksum.rc
//
#define IDC_ADDRESS                     100
#define IDD_MAINWINDOW                  101
#define IDR_MAIN_MENU                   101
#define IDI_MAIN_ICON                   101
#define IDA_ACCELERATOR                 101
#define IDC_DATA                        101
#define IDC_CHECKSUM                    102
#define IDC_CALCULATE                   103
#define IDC_ADDRESSTYPE                 104
#define IDC_DATATYPE                    105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40000
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
